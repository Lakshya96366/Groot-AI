let conversationId = null;
let isBotTyping = false;

// DOM Elements
const chatMessages = document.getElementById('chatMessages');
const userInput = document.getElementById('userInput');
const sendButton = document.getElementById('sendButton');
const clearButton = document.getElementById('clearButton');

// Initialization
window.onload = displayInitialMessage;

// Event Listeners
sendButton.addEventListener('click', sendMessage);
clearButton.addEventListener('click', resetChat);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

// Chat Functions
async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    addMessage(message, true);
    userInput.value = '';
    showTypingIndicator();

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message, conversationId })
        });

        const data = await response.json();
        conversationId = data.conversationId;
        addMessage(data.text, false, true);
    } catch (error) {
        console.error('Error:', error);
        addMessage("Sorry, I'm having trouble responding.", false);
    }

    hideTypingIndicator();
}

function addMessage(message, isUser = false, isHTML = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;

    const avatar = document.createElement('div');
    avatar.className = `avatar ${isUser ? 'user-avatar' : 'bot-avatar'}`;
    avatar.innerHTML = isUser ? '👤' : '🌱';

    const content = document.createElement('div');
    content.className = 'message-content';
    content.innerHTML = isHTML ? message : message.replace(/\n/g, '<br>');

    messageDiv.append(avatar, content);
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
    if (isBotTyping) return;
    isBotTyping = true;

    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message';
    typingDiv.id = 'typingIndicator';

    typingDiv.innerHTML = `
        <div class="avatar bot-avatar">🌱</div>
        <div class="message-content">
            <div class="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    `;

    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function hideTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
    isBotTyping = false;
}

function displayInitialMessage() {
    chatMessages.innerHTML = '';
    addMessage(`
        <p>👋 Hello! I'm your <strong>AgriAI Assistant</strong>. 🌱 I can help with problems like:</p>
        <p><strong>1.</strong> Farming Practices <br>
        <strong>2.</strong> Pest control<br>
        <strong>3.</strong> Soil health<br>
        <strong>4.</strong> Farming techniques<br>
        <strong>5.</strong> Seed selection etc</p>
        <br>
        <p><strong>Ask me questions like:</strong></p>
        <p>• What are the benefits of crop rotation?</p>
        <p>• How can I prevent pests from attacking my crops?</p>
        <p>• What is the ideal soil pH for growing vegetables?</p>
        <p>• How do I select the best seeds for my farm?</p>
    `, false, true);
}

function resetChat() {
    conversationId = null;
    chatMessages.innerHTML = '';
    displayInitialMessage();
}